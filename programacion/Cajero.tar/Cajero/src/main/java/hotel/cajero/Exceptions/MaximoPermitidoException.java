package hotel.cajero.Exceptions;

public class MaximoPermitidoException extends Exception {
    public MaximoPermitidoException(String mensaje) {
        super(mensaje);
    }
}
