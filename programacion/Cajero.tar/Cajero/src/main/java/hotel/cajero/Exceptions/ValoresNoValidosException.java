package hotel.cajero.Exceptions;

public class ValoresNoValidosException extends Exception {
    public ValoresNoValidosException(String mensaje) {
        super(mensaje);
    }
}
