package hotel.cajero.Exceptions;

public class UsuarioNoEncontrado extends Exception {
    public UsuarioNoEncontrado(String mensaje) {
        super(mensaje);
    }
}
